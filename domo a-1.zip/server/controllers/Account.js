const models = require('../models');
const Account = models.Account;

const signup = (request, response) => {
    const req = request;
    const res = response;

    req.bod.username = `${req.body.username}`;
    req.bod.pass = `${req.body.pass}`;
    req.bod.pass2 = `${req.body.pass2}`;

    if (!req.body.username || !req.body.pass || !req.body.pass2) {
        return res.status(400).json({ error: 'RAWR! All fields required' });
    }
    if (!req.body.pass !== req.body.pass2) {
        return res.status(400).json({
            error: 'RAWR! Passwords do not match '
        });
    }
}


const loginPage = (req, res) => {
    res.render('login');
};

const signupPage = (req, res) => {
    res.render('signup');
};

const logout = (req, res) => {
    res.redirect('/');
};

const login = (req, res) => {};

const signup = (req, res) => {};

module.exports.loginPage = loginPage;
module.exports.login = login;
module.exports.logout = logout;
module.exports.signupPage = signupPage;
module.exports.signup = signup;